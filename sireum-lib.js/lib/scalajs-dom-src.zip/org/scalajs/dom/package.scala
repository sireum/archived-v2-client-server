package org.scalajs

package object dom extends dom.Window with scalajs.js.GlobalScope
